Open the "Adjprog" Application
then
Click the Select Button
Model Name: Printer Model
Port: Auto Selection
Then 
OK
Then
Click the Particular Adjustment Mode
and then
Select the Waste ink pad Counter
Then
Click the OK then
Click the Check Button

Then
click the checkbox (Main pad Counter) then
Click the Initialize Button

then Tap to Printer Power button.

Thank you.


